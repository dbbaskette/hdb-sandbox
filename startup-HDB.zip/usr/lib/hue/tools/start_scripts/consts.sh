export RUN_DIR=/usr/lib/tutorials/tutorials_app/run
export GIT_REPO=git@github.com:hortonworks/sandbox-tutorials.git

export TUTORIALS_HOME=/usr/lib/tutorials
export GIT_FILES=$TUTORIALS_HOME/sandbox-tutorials

export BRANCH=master
export TUTORIALS_BRANCH=HDP2.4

export HUE_HOME_DIR=/usr/lib/hue
